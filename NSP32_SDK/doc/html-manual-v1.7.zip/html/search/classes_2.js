var searchData=
[
  ['doubledatapair',['DoubleDataPair',['../class_double_data_pair.html',1,'']]]
];
