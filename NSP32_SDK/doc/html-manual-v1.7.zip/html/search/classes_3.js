var searchData=
[
  ['filterinformation',['FilterInformation',['../struct_filter_information.html',1,'']]]
];
