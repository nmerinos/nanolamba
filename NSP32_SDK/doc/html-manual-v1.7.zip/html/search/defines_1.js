var searchData=
[
  ['ae_5ffunc_5fmessage_5flight_5ftoo_5flow',['AE_FUNC_MESSAGE_LIGHT_TOO_LOW',['../nsp__base__def_8h.html#aea462890c67e9792d19e9721d5acc708',1,'nsp_base_def.h']]],
  ['ae_5ffunc_5fmessage_5flight_5ftoo_5fstrong',['AE_FUNC_MESSAGE_LIGHT_TOO_STRONG',['../nsp__base__def_8h.html#a465dee3ae2d6296efad0f3320edc5d80',1,'nsp_base_def.h']]],
  ['ae_5ffunc_5fpixel_5fvariation_5fsize',['AE_FUNC_PIXEL_VARIATION_SIZE',['../nsp__base__def_8h.html#a18b08c9b7ac374be4c66672dd7ba69fc',1,'nsp_base_def.h']]],
  ['ae_5ffunc_5fsaturation_5flimit',['AE_FUNC_SATURATION_LIMIT',['../nsp__base__def_8h.html#a81e40d961ce8f426f191c5d0b4c127b2',1,'nsp_base_def.h']]],
  ['allow_5fframe_5fdata_5fcasting_5fto_5finteger',['ALLOW_FRAME_DATA_CASTING_TO_INTEGER',['../nsp__device__interface__stm__usb_8h.html#a6fe1c54684e886277db27806a4d68876',1,'nsp_device_interface_stm_usb.h']]],
  ['allow_5fnegative_5fsignal',['ALLOW_NEGATIVE_SIGNAL',['../nsp__device__interface__stm__usb_8h.html#af3d1d59ca0b098f3146ff4f12a55e904',1,'nsp_device_interface_stm_usb.h']]],
  ['appinitstate_5fbackground_5ffile_5fnot_5fexist',['APPINITSTATE_BACKGROUND_FILE_NOT_EXIST',['../nsp__sdk__def_8h.html#afd85d1b9e54bb49c4f44313aa38156bd',1,'nsp_sdk_def.h']]],
  ['appinitstate_5fdark_5ffile_5fnot_5fexist',['APPINITSTATE_DARK_FILE_NOT_EXIST',['../nsp__sdk__def_8h.html#a5643b5d38ed4729c1b031fb65eabbbc9',1,'nsp_sdk_def.h']]],
  ['appinitstate_5fdevice_5fnotfound',['APPINITSTATE_DEVICE_NOTFOUND',['../nsp__sdk__def_8h.html#ac362784ca61ee00955e5b1e746eccb36',1,'nsp_sdk_def.h']]],
  ['appinitstate_5feverything_5fok',['APPINITSTATE_EVERYTHING_OK',['../nsp__sdk__def_8h.html#a8ca692302a70e1d4234c43ca5537204d',1,'nsp_sdk_def.h']]],
  ['appinitstate_5ffr_5ffile_5fnot_5fexist',['APPINITSTATE_FR_FILE_NOT_EXIST',['../nsp__sdk__def_8h.html#a0f961c4529ebed8507b4f7b93b285af5',1,'nsp_sdk_def.h']]],
  ['appinitstate_5fsysresource_5flow',['APPINITSTATE_SYSRESOURCE_LOW',['../nsp__sdk__def_8h.html#a0df299cf81ff075a4be9e1b7f1b45608',1,'nsp_sdk_def.h']]]
];
