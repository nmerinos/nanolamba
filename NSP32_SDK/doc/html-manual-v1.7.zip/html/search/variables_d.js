var searchData=
[
  ['orig',['orig',['../struct___s_sensor_tray_info_data.html#a78f23bef76f7c34b8cd4f22c89e3ccfd',1,'_SSensorTrayInfoData']]],
  ['orig_5fx',['orig_x',['../struct___s_sensor_loc_in_tray.html#afa4ba9c7e34e77c628788aa9902cda4a',1,'_SSensorLocInTray']]],
  ['orig_5fy',['orig_y',['../struct___s_sensor_loc_in_tray.html#a90675133e09e2af8ac6393732dc299d1',1,'_SSensorLocInTray']]]
];
