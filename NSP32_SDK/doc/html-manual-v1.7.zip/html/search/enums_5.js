var searchData=
[
  ['recon_5falgotype',['RECON_ALGOTYPE',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388',1,'nsp_sdk_def.h']]]
];
