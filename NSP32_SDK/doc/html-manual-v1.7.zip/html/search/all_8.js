var searchData=
[
  ['h',['h',['../struct_s_l_c_h.html#ae701c152a0033f625eb6274996812f5c',1,'SLCH']]],
  ['handle',['handle',['../structusb__dev__handle.html#abfcaee9ee73bdd125b2d41a6af1340e0',1,'usb_dev_handle::handle()'],['../nsp__base__def_8h.html#ab521aa5010fb1afb801a899a55569e03',1,'HANDLE():&#160;nsp_base_def.h'],['../nsp__sdk__def_8h.html#ab521aa5010fb1afb801a899a55569e03',1,'HANDLE():&#160;nsp_sdk_def.h']]],
  ['hdr',['hdr',['../struct_s_data_acq_condition.html#aa360cb40215930b281780217b805ebe0',1,'SDataAcqCondition']]],
  ['hdrscale',['hdrscale',['../struct_s_data_acq_condition.html#a5863691dd7828321477ddeb3740995e5',1,'SDataAcqCondition']]],
  ['hpk_5fcis_5fmode_5fall_5freset',['HPK_CIS_MODE_ALL_RESET',['../nsp__device__interface__stm__usb__protocols_8h.html#a11f46a222a61a7a3f58b0afc8f08b85c',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fcontinuous_5fcapture',['HPK_CIS_MODE_CONTINUOUS_CAPTURE',['../nsp__device__interface__stm__usb__protocols_8h.html#a47c7288f915c6dd6739bade6b729fd28',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fpower_5fon_5fand_5fwait',['HPK_CIS_MODE_POWER_ON_AND_WAIT',['../nsp__device__interface__stm__usb__protocols_8h.html#a0bf6a66855dc36b861dd2e5678f38f5d',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fpower_5fsave',['HPK_CIS_MODE_POWER_SAVE',['../nsp__device__interface__stm__usb__protocols_8h.html#a1426bf3d73a6f71dfd83c02a931c0c7d',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fsingle_5fcapture',['HPK_CIS_MODE_SINGLE_CAPTURE',['../nsp__device__interface__stm__usb__protocols_8h.html#a8b70190aa807185d1d561e55bcb267ee',1,'nsp_device_interface_stm_usb_protocols.h']]]
];
