var searchData=
[
  ['handle',['HANDLE',['../nsp__base__def_8h.html#ab521aa5010fb1afb801a899a55569e03',1,'HANDLE():&#160;nsp_base_def.h'],['../nsp__sdk__def_8h.html#ab521aa5010fb1afb801a899a55569e03',1,'HANDLE():&#160;nsp_sdk_def.h']]],
  ['hpk_5fcis_5fmode_5fall_5freset',['HPK_CIS_MODE_ALL_RESET',['../nsp__device__interface__stm__usb__protocols_8h.html#a11f46a222a61a7a3f58b0afc8f08b85c',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fcontinuous_5fcapture',['HPK_CIS_MODE_CONTINUOUS_CAPTURE',['../nsp__device__interface__stm__usb__protocols_8h.html#a47c7288f915c6dd6739bade6b729fd28',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fpower_5fon_5fand_5fwait',['HPK_CIS_MODE_POWER_ON_AND_WAIT',['../nsp__device__interface__stm__usb__protocols_8h.html#a0bf6a66855dc36b861dd2e5678f38f5d',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fpower_5fsave',['HPK_CIS_MODE_POWER_SAVE',['../nsp__device__interface__stm__usb__protocols_8h.html#a1426bf3d73a6f71dfd83c02a931c0c7d',1,'nsp_device_interface_stm_usb_protocols.h']]],
  ['hpk_5fcis_5fmode_5fsingle_5fcapture',['HPK_CIS_MODE_SINGLE_CAPTURE',['../nsp__device__interface__stm__usb__protocols_8h.html#a8b70190aa807185d1d561e55bcb267ee',1,'nsp_device_interface_stm_usb_protocols.h']]]
];
