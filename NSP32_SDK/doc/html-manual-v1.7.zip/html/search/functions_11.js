var searchData=
[
  ['what',['what',['../classnsp__base__exception.html#a419840b5719b9653da324ed5003dcd29',1,'nsp_base_exception']]],
  ['write_5fregister_5fdata',['write_register_data',['../nsp__device__interface__stm__usb_8h.html#ad60bc1f7bae38a5e1e8fa31e05cd5e67',1,'nsp_device_interface_stm_usb.h']]],
  ['write_5froi_5finfo_5fto_5ffw',['write_roi_info_to_fw',['../nsp__device__interface__stm__usb_8h.html#acbdb0a8708c8d13d991d018fe5079400',1,'nsp_device_interface_stm_usb.h']]]
];
