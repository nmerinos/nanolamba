var searchData=
[
  ['fd',['fd',['../structlibusb__pollfd.html#a6bf9823709974cfb204e008eae7d451a',1,'libusb_pollfd']]],
  ['fiber_5fsize',['Fiber_size',['../struct___o_o_irrad_data_file_info.html#abf3187f4d1132029a6408eb58eae5fa6',1,'_OOIrradDataFileInfo']]],
  ['filename',['filename',['../structusb__device.html#a3362eda4e750319186d216b7a1f4dbe3',1,'usb_device']]],
  ['filter_5fdata',['filter_data',['../struct___s_o_l731_data.html#a4192cd3d17ad26edf15289227f9b9770',1,'_SOL731Data::filter_data()'],['../struct___s_apollo_data.html#a462dfa6fe9a95f7c868c3455562e65f1',1,'_SApolloData::filter_data()']]],
  ['filter_5fdata_5fptr',['filter_data_ptr',['../struct_filter_information.html#a3020accdb2b68cf471fb01a430bc20ac',1,'FilterInformation']]],
  ['filter_5fdata_5fwavelength',['filter_data_wavelength',['../struct___s_o_l731_data.html#abd9fd6b90170e9019756fb317a580cfc',1,'_SOL731Data']]],
  ['filter_5fdevice',['filter_device',['../struct___s_o_l731_data.html#a3209c1c29225cf22a78cd651f66d59ef',1,'_SOL731Data']]],
  ['filterout',['filterout',['../struct___s_filter_measurement_data.html#a0220455adeed2e139229d2f8c6a391c9',1,'_SFilterMeasurementData::filterout()'],['../struct___s_filter_data_calib_perf.html#a157417589a2a690d4fa7e51a2edb0feb',1,'_SFilterDataCalibPerf::filterout()']]],
  ['filterout_5fraw_5fwarmup',['filterout_raw_warmUp',['../struct___s_filter_data_calib_perf.html#ae04f73a54f51ba77e568dd9ebf6838d4',1,'_SFilterDataCalibPerf']]],
  ['filterout_5fss1',['filterout_SS1',['../struct___s_filter_data_calib_perf.html#a9f3e491454a2bb07f4ea92b7edc6455b',1,'_SFilterDataCalibPerf']]],
  ['flags',['flags',['../structlibusb__transfer.html#ae26c063df30c2e29835212aad98c6e06',1,'libusb_transfer']]],
  ['frame_5faverage',['frame_average',['../struct___s_titan_plan.html#a1bcbb21aa927bfe42cd77ef36142b5ca',1,'_STitanPlan::frame_average()'],['../struct___o_o_irrad_data_file_info.html#af9236c4c80371eb0cb346b12b21f4d82',1,'_OOIrradDataFileInfo::Frame_average()']]],
  ['frames',['frames',['../struct_s_data_acq_condition.html#ae125fc7a2b16266561781492799d467e',1,'SDataAcqCondition']]],
  ['func_5forder',['func_order',['../struct_s_data_process_plan.html#a8acc949a942f5140c60a74bc60dbf520',1,'SDataProcessPlan']]],
  ['fwhm',['fwhm',['../struct___s_spectrum_peak.html#af2ca73119a8956bb81f5a7f10b128945',1,'_SSpectrumPeak']]]
];
