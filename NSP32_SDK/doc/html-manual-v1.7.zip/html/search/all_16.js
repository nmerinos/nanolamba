var searchData=
[
  ['x',['x',['../struct_s_chromaticity.html#a214f204d7375e394137cd27df5b71238',1,'SChromaticity::x()'],['../struct_s_x_y_z.html#aa428e32e7d14433db0ac1b35d20dcf12',1,'SXYZ::x()'],['../struct_sxy_y.html#ac4b829cf53f4cf8fa0ceefbfce9e2aff',1,'SxyY::x()'],['../struct_c_o_l_o_r.html#a5069a49ff26e8d33cdbeaf0e9dbc9b1a',1,'COLOR::x()'],['../struct___s_sensor_loc_in_tray.html#a054d511511fb9c499fb7ee639030b917',1,'_SSensorLocInTray::x()']]]
];
