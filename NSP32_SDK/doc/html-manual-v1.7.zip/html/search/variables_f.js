var searchData=
[
  ['r',['r',['../struct_s_r_g_b.html#a65e042af7c0210c8b58755112b3b63b9',1,'SRGB::r()'],['../struct_s_r_g_bf.html#a4ec43023f6654436a57b9b90cff097d8',1,'SRGBf::r()']]],
  ['raw',['raw',['../struct_s_one_filter_data.html#a500432aee9e961d6876488c32d9890d9',1,'SOneFilterData']]],
  ['rc',['rc',['../structlibusb__version.html#a99937642131c0559025bad92e7f51f27',1,'libusb_version']]],
  ['resolution',['resolution',['../struct___s_o_l731_data.html#acce30deb2657d69da0132569aea1eff5',1,'_SOL731Data::resolution()'],['../struct___s_device_info.html#a4c59d9f1b465ab10394a099896b8a685',1,'_SDeviceInfo::resolution()']]],
  ['root_5fdev',['root_dev',['../structusb__bus.html#a7235b4bb1221d0243002789162dacbe4',1,'usb_bus']]],
  ['row',['row',['../struct___s_sensor_loc_in_tray.html#a0e742c2eb3f9e78d3ac62fa1a3e4be26',1,'_SSensorLocInTray']]],
  ['row_5finterval',['row_interval',['../struct___s_sensor_tray_info_data.html#aa50918d9d4b4efe229bea2ea76d8d32f',1,'_SSensorTrayInfoData']]],
  ['rows',['rows',['../struct___s_sensor_tray_info_data.html#a4c394b24cea208a36c2eeccf2e2719b6',1,'_SSensorTrayInfoData']]]
];
