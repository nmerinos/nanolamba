var searchData=
[
  ['bsgeterrorstring',['bsGetErrorString',['../nsp__base__api_8h.html#aedde6f1871f6c7a4115101562fc1266c',1,'nsp_base_api.h']]]
];
