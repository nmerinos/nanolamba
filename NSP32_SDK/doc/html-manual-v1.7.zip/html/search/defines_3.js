var searchData=
[
  ['cmf_5fend_5fwavelength',['CMF_END_WAVELENGTH',['../nsp__sdk__def_8h.html#a7bdac15245b468717be75a48ad690453',1,'nsp_sdk_def.h']]],
  ['cmf_5fstart_5fwavelength',['CMF_START_WAVELENGTH',['../nsp__sdk__def_8h.html#a99393339e808904459309f846f7e8b66',1,'nsp_sdk_def.h']]],
  ['cmf_5fwavelength_5fstep',['CMF_WAVELENGTH_STEP',['../nsp__sdk__def_8h.html#ab3785ee72333d69ecd32d9d9c002f5c1',1,'nsp_sdk_def.h']]],
  ['controller_5fboard_5fstm',['CONTROLLER_BOARD_STM',['../nsp__base__def_8h.html#a8b85309bdb473716f6d45bff7bc357f8',1,'CONTROLLER_BOARD_STM():&#160;nsp_base_def.h'],['../lusb_8h.html#a8b85309bdb473716f6d45bff7bc357f8',1,'CONTROLLER_BOARD_STM():&#160;lusb.h']]],
  ['convert_5finteg_5ftime_5fto_5fss',['CONVERT_INTEG_TIME_TO_SS',['../nsp__core__common_8h.html#ac6b2af89fbe3493bb3712f1619754b13',1,'CONVERT_INTEG_TIME_TO_SS():&#160;nsp_core_common.h'],['../nsp__device__interface__stm__usb_8h.html#ac6b2af89fbe3493bb3712f1619754b13',1,'CONVERT_INTEG_TIME_TO_SS():&#160;nsp_device_interface_stm_usb.h']]],
  ['convert_5fss_5fto_5finteg_5ftime',['CONVERT_SS_TO_INTEG_TIME',['../nsp__core__common_8h.html#a9033c4502bf7d728a1998eae2bcc6465',1,'CONVERT_SS_TO_INTEG_TIME():&#160;nsp_core_common.h'],['../nsp__device__interface__stm__usb_8h.html#a9033c4502bf7d728a1998eae2bcc6465',1,'CONVERT_SS_TO_INTEG_TIME():&#160;nsp_device_interface_stm_usb.h']]],
  ['convertmode_5fignore_5fblank_5fpixel',['CONVERTMODE_IGNORE_BLANK_PIXEL',['../nsp__sdk__def_8h.html#a51b57c892493adca7404acdf9ec56563',1,'nsp_sdk_def.h']]],
  ['convertmode_5fnone',['CONVERTMODE_NONE',['../nsp__sdk__def_8h.html#af9f29cdaac279fb9af1ac886bc384a18',1,'nsp_sdk_def.h']]],
  ['convertmode_5fnormalize_5f0to1',['CONVERTMODE_NORMALIZE_0TO1',['../nsp__sdk__def_8h.html#a3b3481ebdfa5780fa3e8a0e72bf84c53',1,'nsp_sdk_def.h']]],
  ['convertmode_5fnormalize_5f0to100',['CONVERTMODE_NORMALIZE_0TO100',['../nsp__sdk__def_8h.html#a4f5478a8ea74f8887e9c748404115a22',1,'nsp_sdk_def.h']]],
  ['crystal_5fcolor_5fnan',['CRYSTAL_COLOR_NAN',['../nsp__base__types_8h.html#a54ddbdd4939d06999873fcf6f15f0635',1,'nsp_base_types.h']]],
  ['crystal_5flib_5fnan',['CRYSTAL_LIB_NAN',['../nsp__base__types_8h.html#a448f0c077abf07077cae1a33fe07669e',1,'nsp_base_types.h']]],
  ['crystal_5flib_5fneg_5finf',['CRYSTAL_LIB_NEG_INF',['../nsp__base__types_8h.html#aaa2b72c7c86260e6fa6dbe0127089cfc',1,'nsp_base_types.h']]],
  ['crystal_5flib_5fpos_5finf',['CRYSTAL_LIB_POS_INF',['../nsp__base__types_8h.html#a67505297642dd9b417f2b4529bb0cc9c',1,'nsp_base_types.h']]]
];
