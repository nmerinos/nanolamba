var searchData=
[
  ['nano',['nano',['../structlibusb__version.html#afbe4cf431bea706294667e333878508c',1,'libusb_version']]],
  ['next',['next',['../structusb__device.html#af816e97db5f8f02a7609f325735bb5f0',1,'usb_device::next()'],['../structusb__bus.html#a7664167bbffd52eb4f7b9d5f8e49de7d',1,'usb_bus::next()']]],
  ['normalized',['normalized',['../struct_s_data_acq_condition.html#a8a5af22ca7df42fb25c101550b510863',1,'SDataAcqCondition']]],
  ['nu',['NU',['../struct___s_model_config_for_s_v_m.html#a6beb9050f2e2b47b029a8ce2454f4d50',1,'_SModelConfigForSVM']]],
  ['num_5faltsetting',['num_altsetting',['../structlibusb__interface.html#afc930be16a60980424f64a88b23c10e9',1,'libusb_interface::num_altsetting()'],['../structusb__interface.html#aa4f464af60066d059eb5c75b91870a6c',1,'usb_interface::num_altsetting()']]],
  ['num_5faxis',['num_axis',['../struct___s_sensor_i_d_loc_map_data.html#a83881a7e369cc416ea4be9ab4a5c80cf',1,'_SSensorIDLocMapData']]],
  ['num_5fchannels',['num_channels',['../struct___s_l_e_d_matrix_config.html#a17738ab1c37f6b36aa46945caafc71cf',1,'_SLEDMatrixConfig']]],
  ['num_5fchildren',['num_children',['../structusb__device.html#a88363220bd62e20d3fd5672a8be44a44',1,'usb_device']]],
  ['num_5ffilters',['num_filters',['../struct_filter_information.html#af844b6c282e84861f66535cbfabffaf1',1,'FilterInformation']]],
  ['num_5fiso_5fpackets',['num_iso_packets',['../structlibusb__transfer.html#a87d725a5521c26832fdc13611220014d',1,'libusb_transfer']]],
  ['num_5fresolution',['num_resolution',['../struct_filter_information.html#a54d3b96559456ce514698e56fdf2d9af',1,'FilterInformation']]],
  ['num_5fvalid_5ffilters',['num_valid_filters',['../struct_filter_information.html#a11761de27c94ae6adf70787bbcb765c8',1,'FilterInformation']]]
];
