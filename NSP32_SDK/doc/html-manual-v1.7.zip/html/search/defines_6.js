var searchData=
[
  ['filter_5fdata_5fcorrection_5fmode_5fadvanced',['FILTER_DATA_CORRECTION_MODE_ADVANCED',['../nsp__base__types_8h.html#a8d76df8daf74bc27ad96c95e897eb909',1,'nsp_base_types.h']]],
  ['filter_5fdata_5fcorrection_5fmode_5fnone',['FILTER_DATA_CORRECTION_MODE_NONE',['../nsp__base__types_8h.html#a5f0fc5cc731ccc5e7ce4d49fbf650d89',1,'nsp_base_types.h']]],
  ['filter_5fdata_5fcorrection_5fmode_5fonboard',['FILTER_DATA_CORRECTION_MODE_ONBOARD',['../nsp__base__types_8h.html#af375df31453940290ecd021abd2f2cd1',1,'nsp_base_types.h']]],
  ['filter_5fvalue_5fof_5fsaturation',['FILTER_VALUE_OF_SATURATION',['../nsp__base__def_8h.html#a6fca8f2f0a76bda4e9586fe4699ea525',1,'nsp_base_def.h']]],
  ['fma_5fmax_5fnum_5fbuffers',['FMA_MAX_NUM_BUFFERS',['../nsp__device__interface__stm__usb_8h.html#a3f40148fdd27f3718565310b57a997d2',1,'nsp_device_interface_stm_usb.h']]],
  ['frame_5fnum_5ffor_5fskip',['FRAME_NUM_FOR_SKIP',['../nsp__device__interface__stm__usb_8h.html#a72cfcd8b1c5bd45cdcfd377cc314fe19',1,'nsp_device_interface_stm_usb.h']]]
];
