var searchData=
[
  ['g',['g',['../struct_s_r_g_b.html#a1fe095bf29f2ef395e47732fc69f4a0b',1,'SRGB::g()'],['../struct_s_r_g_bf.html#aef8dc79bb6d139d5fbfbb055757045e7',1,'SRGBf::g()']]],
  ['gain',['gain',['../struct_s_data_acq_condition.html#a14282305eca33a03d7c3601377a14826',1,'SDataAcqCondition']]],
  ['gamma',['gamma',['../struct___s_model_config_for_s_v_m.html#a96c0316340668bddbfcbd11c7d04444d',1,'_SModelConfigForSVM']]],
  ['gray_5ffilterout',['gray_filterout',['../struct___s_filter_ref_data.html#a5912f177c544c50495b6858700f9eb90',1,'_SFilterRefData']]]
];
