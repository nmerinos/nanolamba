var searchData=
[
  ['enable_5fframe_5fmoving_5faverage',['enable_frame_moving_average',['../classnsp__device__interface.html#a7b218d4ad228a857cd051ef35b248486',1,'nsp_device_interface::enable_frame_moving_average()'],['../classnsp__device__interface__base.html#a362342a3707894af858e5f89899fd562',1,'nsp_device_interface_base::enable_frame_moving_average()']]],
  ['enable_5fspatial_5ffiltering',['enable_spatial_filtering',['../classnsp__device__interface.html#ad067e8b60a5b8496fd526b82187b9cec',1,'nsp_device_interface::enable_spatial_filtering()'],['../classnsp__device__interface__base.html#a294867834653cc5a11d7e12ff80c5c0a',1,'nsp_device_interface_base::enable_spatial_filtering()']]],
  ['exposure_5ftim_5fms_5fto_5fshutter',['exposure_tim_ms_to_shutter',['../classnsp__device__interface.html#abc6ee6e7a766c7ac74c0df57e493f299',1,'nsp_device_interface::exposure_tim_ms_to_shutter()'],['../classnsp__device__interface__base.html#aab32b2b0903d059a3d811ce0c7c8b63d',1,'nsp_device_interface_base::exposure_tim_ms_to_shutter()']]]
];
