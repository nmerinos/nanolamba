var searchData=
[
  ['threshold_5ffor_5fquality_5fscore',['THRESHOLD_FOR_QUALITY_SCORE',['../nsp__sdk__def_8h.html#a55f595039c8110b109e397d3151b9544',1,'nsp_sdk_def.h']]],
  ['time',['TIME',['../nsp__sdk__def_8h.html#ae808562e29fca8d705fa0b386732b3b6',1,'nsp_sdk_def.h']]],
  ['to_5fdegree',['TO_DEGREE',['../nsp__sdk__def_8h.html#a7eb5d6a16382a3c5ea8d5a7e81ed6ce9',1,'nsp_sdk_def.h']]],
  ['to_5fradian',['TO_RADIAN',['../nsp__sdk__def_8h.html#a05c57f856c51afdea9c63618e27f979f',1,'nsp_sdk_def.h']]],
  ['toolbar_5fbutton_5fsize',['TOOLBAR_BUTTON_SIZE',['../nsp__sdk__def_8h.html#ae7521c50f5b9e9a914c4290ce14b0cdb',1,'nsp_sdk_def.h']]],
  ['toolbar_5ficon_5fsize',['TOOLBAR_ICON_SIZE',['../nsp__sdk__def_8h.html#afb8081a360043a246bb9083d4abdec87',1,'nsp_sdk_def.h']]],
  ['total_5fnum_5fof_5fsensor_5fdesign_5ftypes',['TOTAL_NUM_OF_SENSOR_DESIGN_TYPES',['../nsp__sdk__def_8h.html#ae1ded54fc2946f15891c3a303fd0dc18',1,'nsp_sdk_def.h']]]
];
