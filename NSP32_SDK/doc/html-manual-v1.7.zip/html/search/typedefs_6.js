var searchData=
[
  ['usb_5fdev_5fhandle',['usb_dev_handle',['../lusb_8h.html#ab6040b929dd43a9c73ca23f92097158b',1,'lusb.h']]]
];
