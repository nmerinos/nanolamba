var searchData=
[
  ['kernel_5ftype',['kernel_type',['../struct___s_model_config_for_s_v_m.html#a316d8756e51da606f78a35256940da2c',1,'_SModelConfigForSVM']]],
  ['key',['key',['../class_int_data_pair.html#a96a925e7cfa91539d0150d36e69dbdb8',1,'IntDataPair::key()'],['../class_double_data_pair.html#ae9a49d322327600848ff3ffb41b99b01',1,'DoubleDataPair::key()']]]
];
