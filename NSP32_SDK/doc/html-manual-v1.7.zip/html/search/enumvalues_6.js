var searchData=
[
  ['recon_5falgotype_5fnnls_5fl1',['RECON_ALGOTYPE_NNLS_L1',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388a7ef906e4208d01b23e7195defd19d008',1,'nsp_sdk_def.h']]],
  ['recon_5falgotype_5fnnls_5fsc',['RECON_ALGOTYPE_NNLS_SC',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388a4d43f8fa7d7fae1f93cf3ccdbd6cbf0a',1,'nsp_sdk_def.h']]],
  ['recon_5falgotype_5fnnls_5fsca_5fgcv',['RECON_ALGOTYPE_NNLS_SCA_GCV',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388a0c2a6a3430ef222249ecbc6bded3ea90',1,'nsp_sdk_def.h']]],
  ['recon_5falgotype_5fnnls_5fsca_5flcurve',['RECON_ALGOTYPE_NNLS_SCA_LCURVE',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388a5a0900ca765e8718b5b56b3315209d23',1,'nsp_sdk_def.h']]],
  ['recon_5falgotype_5fnone',['RECON_ALGOTYPE_NONE',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388aed7ca28dfbb47c3c5ef3357b1c8012fc',1,'nsp_sdk_def.h']]],
  ['recon_5falgotype_5ftnnls_5fgcv',['RECON_ALGOTYPE_TNNLS_GCV',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388a81690e618d770f4a3a12e35101df84b7',1,'nsp_sdk_def.h']]],
  ['recon_5falgotype_5ftnnls_5flcurve',['RECON_ALGOTYPE_TNNLS_LCURVE',['../nsp__sdk__def_8h.html#a219b368ddb6582b0a483df30c99e3388a1b3658d37b79e238124689c7e03cb713',1,'nsp_sdk_def.h']]]
];
