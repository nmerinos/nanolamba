var searchData=
[
  ['libusb_5fcontext',['libusb_context',['../libusb_8h.html#a4ec088aa7b79c4a9599e39bf36a72833',1,'libusb.h']]],
  ['libusb_5fdevice',['libusb_device',['../libusb_8h.html#a77eedd00d01eb7569b880e861a971c2b',1,'libusb.h']]],
  ['libusb_5fdevice_5fhandle',['libusb_device_handle',['../libusb_8h.html#a7df95821d20d27b5597f1d783749d6a4',1,'libusb.h']]],
  ['libusb_5fhotplug_5fcallback_5ffn',['libusb_hotplug_callback_fn',['../libusb_8h.html#a34e9904eb8e5124057a866f777cc99a8',1,'libusb.h']]],
  ['libusb_5fhotplug_5fcallback_5fhandle',['libusb_hotplug_callback_handle',['../libusb_8h.html#a4868157346bbf2c70b6af0cb0a6c0094',1,'libusb.h']]],
  ['libusb_5fpollfd_5fadded_5fcb',['libusb_pollfd_added_cb',['../libusb_8h.html#a291d7463aefd0de6209b537db4d06e70',1,'libusb.h']]],
  ['libusb_5fpollfd_5fremoved_5fcb',['libusb_pollfd_removed_cb',['../libusb_8h.html#abff1d67f33725c93ef6dff699335c225',1,'libusb.h']]]
];
