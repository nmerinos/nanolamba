var searchData=
[
  ['usb_5fbus',['usb_bus',['../structusb__bus.html',1,'']]],
  ['usb_5fconfig_5fdescriptor',['usb_config_descriptor',['../structusb__config__descriptor.html',1,'']]],
  ['usb_5fctrl_5fsetup',['usb_ctrl_setup',['../structusb__ctrl__setup.html',1,'']]],
  ['usb_5fdescriptor_5fheader',['usb_descriptor_header',['../structusb__descriptor__header.html',1,'']]],
  ['usb_5fdev_5fhandle',['usb_dev_handle',['../structusb__dev__handle.html',1,'']]],
  ['usb_5fdevice',['usb_device',['../structusb__device.html',1,'']]],
  ['usb_5fdevice_5fdescriptor',['usb_device_descriptor',['../structusb__device__descriptor.html',1,'']]],
  ['usb_5fendpoint_5fdescriptor',['usb_endpoint_descriptor',['../structusb__endpoint__descriptor.html',1,'']]],
  ['usb_5fhid_5fdescriptor',['usb_hid_descriptor',['../structusb__hid__descriptor.html',1,'']]],
  ['usb_5finterface',['usb_interface',['../structusb__interface.html',1,'']]],
  ['usb_5finterface_5fdescriptor',['usb_interface_descriptor',['../structusb__interface__descriptor.html',1,'']]],
  ['usb_5fstring_5fdescriptor',['usb_string_descriptor',['../structusb__string__descriptor.html',1,'']]],
  ['usbdevhandle',['UsbDevHandle',['../struct_usb_dev_handle.html',1,'']]],
  ['usbdevid',['UsbDevId',['../struct_usb_dev_id.html',1,'']]]
];
