var searchData=
[
  ['bin_5fstring_5fto_5fnum',['BIN_STRING_TO_NUM',['../nsp__base__types_8h.html#a764e6e62128f5b88a0fb9c360ca77298',1,'nsp_base_types.h']]],
  ['blank_5ftime_5fscale_5ffactor',['BLANK_TIME_SCALE_FACTOR',['../nsp__device__interface__stm__usb_8h.html#a80dc46734753f5e795d6f246b7254dd2',1,'nsp_device_interface_stm_usb.h']]],
  ['bool',['BOOL',['../nsp__base__def_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;nsp_base_def.h'],['../nsp__sdk__def_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;nsp_sdk_def.h'],['../nsp__device__api_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;nsp_device_api.h']]]
];
