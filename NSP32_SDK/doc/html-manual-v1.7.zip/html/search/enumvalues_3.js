var searchData=
[
  ['filtertype_5fsf_5fver1_5f1a',['FilterType_SF_Ver1_1A',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6ac39ebf6badc99e061ede0f7d0bdf3d51',1,'nsp_sdk_def.h']]],
  ['filtertype_5fsf_5fver1_5f2a',['FilterType_SF_Ver1_2A',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6ad8242d20b72e59b144d8e5df6a73f75a',1,'nsp_sdk_def.h']]],
  ['filtertype_5fsf_5fver1_5f3a',['FilterType_SF_Ver1_3A',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6a2bee0146a938f33f966be03236763325',1,'nsp_sdk_def.h']]],
  ['filtertype_5fsf_5fver2_5f1a',['FilterType_SF_Ver2_1A',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6abc0530a47b7f47971b7a1139db25584c',1,'nsp_sdk_def.h']]],
  ['filtertype_5fsf_5fver2_5f2a',['FilterType_SF_Ver2_2A',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6a1ae76238ef2d41b68d6a05fe86831c77',1,'nsp_sdk_def.h']]],
  ['filtertype_5fsf_5fver2_5f3a',['FilterType_SF_Ver2_3A',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6adbc2d320934c6617d9f3d6116dc5ab08',1,'nsp_sdk_def.h']]],
  ['filtertype_5ftotalnum',['FilterType_TotalNum',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6ab3bade81d6a01bde38247167d5ba6caa',1,'nsp_sdk_def.h']]],
  ['filtertype_5funknown',['FilterType_Unknown',['../nsp__sdk__def_8h.html#a4b5ad603d65bc2b5357891f7ddbe93f6acb4cdc2cf928f14448dbd31729391e96',1,'nsp_sdk_def.h']]],
  ['fqs_5ftype_5fcorr',['FQS_TYPE_CORR',['../nsp__sdk__def_8h.html#ad95919afd90f544b3e1d8a8db22ce22ca88c4decea79a7806e385d5d2097ea247',1,'nsp_sdk_def.h']]],
  ['fqs_5ftype_5fcorr2',['FQS_TYPE_CORR2',['../nsp__sdk__def_8h.html#ad95919afd90f544b3e1d8a8db22ce22cad4bb61017aef6094d98614944722ab47',1,'nsp_sdk_def.h']]],
  ['fqs_5ftype_5fmse',['FQS_TYPE_MSE',['../nsp__sdk__def_8h.html#ad95919afd90f544b3e1d8a8db22ce22cad3269e7f70711c052e8e111730f3f05c',1,'nsp_sdk_def.h']]],
  ['fqs_5ftype_5fnone',['FQS_TYPE_NONE',['../nsp__sdk__def_8h.html#ad95919afd90f544b3e1d8a8db22ce22cae65190f59032fbf8b7684bc7d2b342ce',1,'nsp_sdk_def.h']]],
  ['fqs_5ftype_5frmse',['FQS_TYPE_RMSE',['../nsp__sdk__def_8h.html#ad95919afd90f544b3e1d8a8db22ce22caf46633f782e944097acbb60ec8157a76',1,'nsp_sdk_def.h']]]
];
