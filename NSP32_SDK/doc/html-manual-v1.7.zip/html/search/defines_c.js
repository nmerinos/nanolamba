var searchData=
[
  ['radian_5fto_5fdegree',['RADIAN_TO_DEGREE',['../nsp__sdk__def_8h.html#a6db8b5d1419d51bc2e74c6a2d59bde62',1,'nsp_sdk_def.h']]],
  ['range_5ffrom_5fsaturation',['RANGE_FROM_SATURATION',['../nsp__base__def_8h.html#adefdd83c82e923597237eb9a12abce0f',1,'nsp_base_def.h']]],
  ['recieved_5fbyte_5fbuffer',['RECIEVED_BYTE_BUFFER',['../nsp__device__interface__stm__usb_8h.html#a20ac91a2ec9d7a87457823dc5837d5d8',1,'nsp_device_interface_stm_usb.h']]],
  ['round',['round',['../nsp__base__def_8h.html#a6ea10f4260b54a61665ead26cb995ba3',1,'nsp_base_def.h']]],
  ['round_5fprec',['round_prec',['../nsp__base__def_8h.html#a1551fd0344aae92d3dbb42a0b71b5f18',1,'nsp_base_def.h']]]
];
