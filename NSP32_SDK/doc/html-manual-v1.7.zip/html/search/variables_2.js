var searchData=
[
  ['c',['C',['../struct_s_l_c_h.html#a5a2a813c8cd7d8316b427adf34d0add1',1,'SLCH::C()'],['../struct___s_model_config_for_s_v_m.html#a7bc7df1183984e387064ba3e1941a4e2',1,'_SModelConfigForSVM::C()']]],
  ['callback',['callback',['../structlibusb__transfer.html#a69c6df011ec23ff3e481cc98bfff0623',1,'libusb_transfer']]],
  ['channel_5findex',['channel_index',['../struct___s_l_e_d_channel_info.html#ad5771b65748b094a727d078d8fa9fafa',1,'_SLEDChannelInfo']]],
  ['channels',['channels',['../struct___s_l_e_d_matrix_config.html#a5f0953ac365b80fb3af3f93d15fec264',1,'_SLEDMatrixConfig']]],
  ['children',['children',['../structusb__device.html#acbc08ca89ba6b78ff7f4eca58ea54e77',1,'usb_device']]],
  ['col',['col',['../struct___s_sensor_loc_in_tray.html#ab8de78b1cea9211075c981611b2b3a11',1,'_SSensorLocInTray']]],
  ['col_5finterval',['col_interval',['../struct___s_sensor_tray_info_data.html#a2cbff95fcffa76c3151a2e493a89ec8a',1,'_SSensorTrayInfoData']]],
  ['cols',['cols',['../struct___s_sensor_tray_info_data.html#abce87d54d0dc3d32e2426ec9d92d6922',1,'_SSensorTrayInfoData']]],
  ['comments',['comments',['../struct___s_o_l731_data.html#a3c3cc6e32a37cc73a9631f722661ead9',1,'_SOL731Data']]],
  ['condition',['condition',['../struct_s_one_filter_data.html#afb2267897a7deb4902c953cc8d168b4d',1,'SOneFilterData']]],
  ['config',['config',['../structusb__device.html#a5f95b1d5fb4be5338c3a8200cc739d7b',1,'usb_device']]],
  ['containerid',['ContainerID',['../structlibusb__container__id__descriptor.html#a0c74613e2be1d8da0e349024a8b73621',1,'libusb_container_id_descriptor']]],
  ['currentdevid',['currentDevId',['../struct_usb_dev_id.html#ab3054a8f900e817c9247a4821a62fb7b',1,'UsbDevId']]]
];
