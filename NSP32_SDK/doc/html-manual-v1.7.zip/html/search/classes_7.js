var searchData=
[
  ['schromaticity',['SChromaticity',['../struct_s_chromaticity.html',1,'']]],
  ['sdataacqcondition',['SDataAcqCondition',['../struct_s_data_acq_condition.html',1,'']]],
  ['sdatacollectplan',['SDataCollectPlan',['../struct_s_data_collect_plan.html',1,'']]],
  ['sdataprocessplan',['SDataProcessPlan',['../struct_s_data_process_plan.html',1,'']]],
  ['slab',['SLAB',['../struct_s_l_a_b.html',1,'']]],
  ['slch',['SLCH',['../struct_s_l_c_h.html',1,'']]],
  ['sonefilterdata',['SOneFilterData',['../struct_s_one_filter_data.html',1,'']]],
  ['srgb',['SRGB',['../struct_s_r_g_b.html',1,'']]],
  ['srgbf',['SRGBf',['../struct_s_r_g_bf.html',1,'']]],
  ['suvw',['SUVW',['../struct_s_u_v_w.html',1,'']]],
  ['sxyy',['SxyY',['../struct_sxy_y.html',1,'']]],
  ['sxyz',['SXYZ',['../struct_s_x_y_z.html',1,'']]]
];
