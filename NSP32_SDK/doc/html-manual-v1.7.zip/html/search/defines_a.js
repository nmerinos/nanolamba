var searchData=
[
  ['m_5flog10e',['M_LOG10E',['../nsp__sdk__def_8h.html#a9ed2b5582226f3896424ff6d2a3ebb14',1,'nsp_sdk_def.h']]],
  ['m_5fpi',['M_PI',['../nsp__base__def_8h.html#ae71449b1cc6e6250b91f539153a7a0d3',1,'M_PI():&#160;nsp_base_def.h'],['../nsp__sdk__def_8h.html#ae71449b1cc6e6250b91f539153a7a0d3',1,'M_PI():&#160;nsp_sdk_def.h']]],
  ['machine_5fprecision',['MACHINE_PRECISION',['../nsp__base__def_8h.html#a71c76ce6fa11d5148a284dcf2ca7b12a',1,'MACHINE_PRECISION():&#160;nsp_base_def.h'],['../nsp__sdk__def_8h.html#a71c76ce6fa11d5148a284dcf2ca7b12a',1,'MACHINE_PRECISION():&#160;nsp_sdk_def.h'],['../nsp__device__api_8h.html#a71c76ce6fa11d5148a284dcf2ca7b12a',1,'MACHINE_PRECISION():&#160;nsp_device_api.h']]],
  ['max_5fshutter_5fspeed',['MAX_SHUTTER_SPEED',['../nsp__sdk__def_8h.html#a6ef0ece68bf98edb67984f668eb99009',1,'nsp_sdk_def.h']]],
  ['message_5fdevice_5fnot_5favailable',['MESSAGE_DEVICE_NOT_AVAILABLE',['../nsp__sdk__def_8h.html#a95330ae71db4ea314c30b1764bc1bda9',1,'nsp_sdk_def.h']]],
  ['min_5fshutter_5fspeed',['MIN_SHUTTER_SPEED',['../nsp__sdk__def_8h.html#afc1f8d9595ddbd9fa7764d1680b2ef00',1,'nsp_sdk_def.h']]]
];
