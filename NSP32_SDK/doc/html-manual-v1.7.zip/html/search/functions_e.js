var searchData=
[
  ['test_5fdevice',['test_device',['../classnsp__device__interface.html#a6349a6561d122af4b2eea6fbafcaadd4',1,'nsp_device_interface::test_device()'],['../classnsp__device__interface__base.html#afb1ce5bcf151cad524343878d4adee2d',1,'nsp_device_interface_base::test_device()']]]
];
