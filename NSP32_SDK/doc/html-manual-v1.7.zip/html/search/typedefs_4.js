var searchData=
[
  ['ooirraddata',['OOIrradData',['../nsp__sdk__def_8h.html#ad36eea0fb52d4412bf74ce5f0090031a',1,'nsp_sdk_def.h']]],
  ['ooirraddatafileinfo',['OOIrradDataFileInfo',['../nsp__sdk__def_8h.html#a80d239ed14ca3d4d7b733ed03cc9d0b9',1,'nsp_sdk_def.h']]]
];
