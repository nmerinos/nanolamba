var searchData=
[
  ['accalculatecolor',['acCalculateColor',['../nsp__core__api__matlab_8h.html#a415545c201d3b7b821aa777472bf356c',1,'acCalculateColor(double *spectrum, double *wavelength, int spectrum_length, double *X, double *Y, double *Z, double *r, double *g, double *b, double *x, double *y, double *z, double *cct):&#160;nsp_core_api_matlab.h'],['../nsp__app__color__api_8h.html#a415545c201d3b7b821aa777472bf356c',1,'acCalculateColor(double *spectrum, double *wavelength, int spectrum_length, double *X, double *Y, double *Z, double *r, double *g, double *b, double *x, double *y, double *z, double *cct):&#160;nsp_app_color_api.h']]],
  ['acfinalize',['acFinalize',['../nsp__core__api__matlab_8h.html#aa89131f0fb87c272668f93a468890eb5',1,'acFinalize(void):&#160;nsp_core_api_matlab.h'],['../nsp__app__color__api_8h.html#aa89131f0fb87c272668f93a468890eb5',1,'acFinalize(void):&#160;nsp_app_color_api.h']]],
  ['acinitialize',['acInitialize',['../nsp__core__api__matlab_8h.html#a668c957f4c5934c0ba557a84974a11e2',1,'acInitialize(void):&#160;nsp_core_api_matlab.h'],['../nsp__app__color__api_8h.html#a668c957f4c5934c0ba557a84974a11e2',1,'acInitialize(void):&#160;nsp_app_color_api.h']]],
  ['acquire_5fframe_5fdata',['acquire_frame_data',['../nsp__device__interface__stm__usb_8h.html#aa89ca9dfbe60a3be8b49cb5791763948',1,'nsp_device_interface_stm_usb.h']]],
  ['acquire_5fframe_5fdata_5f2048',['acquire_frame_data_2048',['../nsp__device__interface__stm__usb_8h.html#a09f65498a7708dbd1780037ca5feedc0',1,'nsp_device_interface_stm_usb.h']]],
  ['acquire_5fframe_5fdata_5fbulk',['acquire_frame_data_bulk',['../nsp__device__interface__stm__usb_8h.html#a4e86f6f45e12cfe0aa4808ffd3d03644',1,'nsp_device_interface_stm_usb.h']]],
  ['acquire_5fframe_5fdata_5fcontrol',['acquire_frame_data_control',['../nsp__device__interface__stm__usb_8h.html#ac01f0e6185be75f776952599a7ba004d',1,'nsp_device_interface_stm_usb.h']]],
  ['acquire_5fsub_5fframe_5fdata',['acquire_sub_frame_data',['../nsp__device__interface__stm__usb_8h.html#a7560f7fbb6b1e582d48ce74faa00b664',1,'nsp_device_interface_stm_usb.h']]],
  ['activate_5fdevice',['activate_device',['../classnsp__device__interface.html#ad90334ca81bb13d4493c352a04a0db51',1,'nsp_device_interface::activate_device()'],['../classnsp__device__interface__base.html#a9292ea22b95ef2c47cdb04a0b447f10c',1,'nsp_device_interface_base::activate_device()']]],
  ['alloc_5ftransfer_5fbulk',['alloc_transfer_bulk',['../nsp__device__interface__stm__usb_8h.html#aa85dce08aa663c691e77afd46a145277',1,'nsp_device_interface_stm_usb.h']]],
  ['alloc_5ftransfer_5fbulk_5fl',['alloc_transfer_bulk_l',['../nsp__device__interface__stm__usb_8h.html#a82c6418bd1d8546fd2988d88bd625fe0',1,'nsp_device_interface_stm_usb.h']]]
];
