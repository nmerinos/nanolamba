var searchData=
[
  ['z',['z',['../struct_s_x_y_z.html#a196f227b96a489d206fd1e3fdb5ef53b',1,'SXYZ::z()'],['../struct_c_o_l_o_r.html#aa0f25a45856513ab9906bc8f56170f9b',1,'COLOR::z()']]],
  ['zero',['zero',['../struct___s_o_l731_data.html#a7407fe5da02b96515661c99f225395b2',1,'_SOL731Data']]]
];
