var searchData=
[
  ['filterdatadouble2d',['FilterDataDouble2D',['../nsp__sdk__def_8h.html#ad8950f0ea4bf4943e005049f2ed022d5',1,'nsp_sdk_def.h']]],
  ['filterdatafloat2d',['FilterDataFloat2D',['../nsp__sdk__def_8h.html#aedd8a9c37ed284a33b3ff8307f156b16',1,'nsp_sdk_def.h']]],
  ['filterdataint2d',['FilterDataInt2D',['../nsp__sdk__def_8h.html#ac8d54f472837fe265f946e8af861253f',1,'nsp_sdk_def.h']]],
  ['float32_5ftype',['FLOAT32_TYPE',['../nsp__base__types_8h.html#a4d1c4c24963946d02476a38bcecca754',1,'nsp_base_types.h']]],
  ['float64_5ftype',['FLOAT64_TYPE',['../nsp__base__types_8h.html#a05248a48bf41ef1603b84187c7a67555',1,'nsp_base_types.h']]]
];
