var searchData=
[
  ['target_5fdn_5fvalue',['target_dn_value',['../struct__nsp__def__auto__exposure__parameters.html#adba8ec5e76bf87cf0a403fe30ca1ec90',1,'_nsp_def_auto_exposure_parameters']]],
  ['temporal_5ffilterout',['temporal_filterout',['../struct___s_filter_measurement_data.html#af1d5cf215000ba8fab34a7e50b742142',1,'_SFilterMeasurementData']]],
  ['threshold',['threshold',['../struct___s_sensor_tray_info_data.html#a8ecc5dfa8f8dc330ea81dbbc7a7fdeb7',1,'_SSensorTrayInfoData']]],
  ['timeout',['timeout',['../structlibusb__transfer.html#a9a12af15ca5b482f5dcaebd26a848cbb',1,'libusb_transfer']]],
  ['timestamp',['Timestamp',['../struct___o_o_irrad_data_file_info.html#a9412fd23bbf07a698887918d69399262',1,'_OOIrradDataFileInfo']]],
  ['total_5fsensors',['total_sensors',['../struct___s_sensor_tray_info_data.html#a065967f00d950fe37136d6b2a8891670',1,'_SSensorTrayInfoData']]],
  ['turn_5fon',['turn_on',['../struct___s_l_e_d_channel_info.html#a924bf87a289f83e9afabea059419a919',1,'_SLEDChannelInfo']]],
  ['type',['type',['../struct___s_device_info.html#adc4c6d13cefe1fc94f581db90e11e1b6',1,'_SDeviceInfo::type()'],['../structlibusb__transfer.html#a7c9fa575986fe9f23bbecb26b766dff1',1,'libusb_transfer::type()']]]
];
