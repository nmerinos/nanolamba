var searchData=
[
  ['ooirraddata',['OOIrradData',['../nsp__sdk__def_8h.html#ad36eea0fb52d4412bf74ce5f0090031a',1,'nsp_sdk_def.h']]],
  ['ooirraddatafileinfo',['OOIrradDataFileInfo',['../nsp__sdk__def_8h.html#a80d239ed14ca3d4d7b733ed03cc9d0b9',1,'nsp_sdk_def.h']]],
  ['orig',['orig',['../struct___s_sensor_tray_info_data.html#a78f23bef76f7c34b8cd4f22c89e3ccfd',1,'_SSensorTrayInfoData']]],
  ['orig_5fx',['orig_x',['../struct___s_sensor_loc_in_tray.html#afa4ba9c7e34e77c628788aa9902cda4a',1,'_SSensorLocInTray']]],
  ['orig_5fy',['orig_y',['../struct___s_sensor_loc_in_tray.html#a90675133e09e2af8ac6393732dc299d1',1,'_SSensorLocInTray']]],
  ['outputlevel',['OutputLevel',['../nsp__base__types_8h.html#a6bcb6b3fe3d480eff62b980e53515a37',1,'nsp_base_types.h']]]
];
