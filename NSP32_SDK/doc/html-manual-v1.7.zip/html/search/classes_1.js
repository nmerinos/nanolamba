var searchData=
[
  ['color',['COLOR',['../struct_c_o_l_o_r.html',1,'']]]
];
